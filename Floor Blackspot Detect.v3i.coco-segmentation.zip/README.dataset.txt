# Floor Blackspot Detect > 2025-01-24 6:12pm
https://universe.roboflow.com/blackspot-floordetect/floor-blackspot-detect

Provided by a Roboflow user
License: CC BY 4.0

